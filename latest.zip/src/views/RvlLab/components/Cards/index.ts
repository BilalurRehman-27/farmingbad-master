import Cards from './Cards'
export default Cards
